const recordBtn = document.getElementById("recordBtn");
const recordText = document.getElementById("recordText");
const outputBox = document.getElementById("outputBox");
const clearBtn = document.getElementById("clearBtn");
const statusText = document.getElementById("statusText");
const previewAudio = document.getElementById("previewAudio");
const deviceSelect = document.getElementById("deviceSelect");

let mediaRecorder = null;
let streamRef = null;
let chunks = [];
let isRecording = false;
let selectedDeviceId = "";

async function loadMicrophones() {
  if (!navigator.mediaDevices || !navigator.mediaDevices.enumerateDevices) {
    statusText.textContent = "Microphone list is not supported in this browser.";
    return;
  }

  const devices = await navigator.mediaDevices.enumerateDevices();
  const microphones = devices.filter((device) => device.kind === "audioinput");

  deviceSelect.innerHTML = "";
  if (microphones.length === 0) {
    const option = document.createElement("option");
    option.value = "";
    option.textContent = "No microphone found";
    deviceSelect.appendChild(option);
    deviceSelect.disabled = true;
    return;
  }

  microphones.forEach((mic, index) => {
    const option = document.createElement("option");
    option.value = mic.deviceId;
    option.textContent = mic.label || `Microphone ${index + 1}`;
    deviceSelect.appendChild(option);
  });

  deviceSelect.disabled = false;
  if (!selectedDeviceId) {
    selectedDeviceId = microphones[0].deviceId;
  }
  deviceSelect.value = selectedDeviceId;
}

async function startRecording() {
  const constraints = selectedDeviceId
    ? { audio: { deviceId: { exact: selectedDeviceId } } }
    : { audio: true };
  try {
    streamRef = await navigator.mediaDevices.getUserMedia(constraints);
  } catch (_error) {
    streamRef = await navigator.mediaDevices.getUserMedia({ audio: true });
  }
  await loadMicrophones();
  mediaRecorder = new MediaRecorder(streamRef);
  chunks = [];

  mediaRecorder.ondataavailable = (event) => {
    if (event.data && event.data.size > 0) {
      chunks.push(event.data);
    }
  };

  mediaRecorder.onstop = async () => {
    const blob = new Blob(chunks, { type: "audio/webm" });
    previewAudio.src = URL.createObjectURL(blob);
    previewAudio.classList.remove("hidden");
    await transcribeAndTranslate(blob);
    if (streamRef) {
      streamRef.getTracks().forEach((track) => track.stop());
    }
  };

  mediaRecorder.start();
  isRecording = true;
  recordBtn.classList.add("recording");
  recordText.textContent = "Stop";
  statusText.textContent = "Recording...";
}

function stopRecording() {
  if (mediaRecorder && isRecording) {
    mediaRecorder.stop();
  }
  isRecording = false;
  recordBtn.classList.remove("recording");
  recordText.textContent = "Record";
  statusText.textContent = "Processing...";
}

async function transcribeAndTranslate(blob) {
  statusText.textContent = "Transcribing Assamese...";
  outputBox.value = "";
  const formData = new FormData();
  formData.append("audio", blob, "audio.webm");

  try {
    const response = await fetch("/api/transcribe", {
      method: "POST",
      body: formData,
    });
    const data = await response.json();
    if (!response.ok) {
      throw new Error(data.error || "Failed to process audio.");
    }
    outputBox.value = data.english_text || "";
    statusText.textContent = "Done.";
  } catch (error) {
    statusText.textContent = `Error: ${error.message}`;
  }
}

recordBtn.addEventListener("click", async () => {
  if (!isRecording) {
    try {
      await startRecording();
    } catch (error) {
      statusText.textContent = `Mic error: ${error.message}`;
    }
  } else {
    stopRecording();
  }
});

clearBtn.addEventListener("click", () => {
  outputBox.value = "";
  statusText.textContent = "";
  previewAudio.classList.add("hidden");
  previewAudio.removeAttribute("src");
});

deviceSelect.addEventListener("change", () => {
  selectedDeviceId = deviceSelect.value;
});

loadMicrophones().catch((error) => {
  statusText.textContent = `Mic list error: ${error.message}`;
});
