import io
import os
from typing import Any

from dotenv import load_dotenv
from flask import Flask, jsonify, render_template, request
from sarvamai import SarvamAI


load_dotenv()
app = Flask(__name__)


def build_sarvam_client() -> SarvamAI:
    api_key = os.getenv("SARVAM_API_KEY")
    if not api_key:
        raise ValueError("SARVAM_API_KEY is missing. Add it in your .env file.")
    return SarvamAI(api_subscription_key=api_key)


def extract_text(response: Any) -> str:
    if response is None:
        return ""
    if isinstance(response, str):
        return response.strip()
    if isinstance(response, dict):
        for key in ("transcript", "text", "output_text", "content", "translated_text", "translation"):
            value = response.get(key)
            if isinstance(value, str) and value.strip():
                return value.strip()
        nested = response.get("result")
        if nested is not None:
            nested_text = extract_text(nested)
            if nested_text:
                return nested_text
        return ""

    for attr in ("transcript", "text", "output_text", "content", "translated_text", "translation"):
        value = getattr(response, attr, None)
        if isinstance(value, str) and value.strip():
            return value.strip()
    return ""


def translate_assamese_to_english(client: SarvamAI, assamese_text: str) -> str:
    response = client.text.translate(
        model="sarvam-translate:v1",
        input=assamese_text,
        source_language_code="as-IN",
        target_language_code="en-IN",
        speaker_gender="Male",
    )
    return extract_text(response).strip()


@app.get("/")
def index() -> str:
    return render_template("index.html")


@app.post("/api/transcribe")
def api_transcribe() -> tuple[Any, int]:
    try:
        audio_file = request.files.get("audio")
        if not audio_file:
            return jsonify({"error": "No audio file provided"}), 400

        audio_bytes = audio_file.read()
        if len(audio_bytes) < 3000:
            return jsonify({"error": "Audio too short"}), 400

        sarvam = build_sarvam_client()
        file_obj = io.BytesIO(audio_bytes)
        file_obj.name = audio_file.filename or "audio.wav"
        response = sarvam.speech_to_text.transcribe(
            file=file_obj,
            model="saaras:v3",
            mode="transcribe",
            language_code="as-IN",
        )
        assamese_text = extract_text(response)
        if not assamese_text:
            return jsonify({"error": "Could not transcribe audio"}), 500

        english_text = translate_assamese_to_english(sarvam, assamese_text)
        return jsonify(
            {
                "assamese_text": assamese_text,
                "english_text": english_text or "(No text returned)",
            }
        ), 200
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


if __name__ == "__main__":
    app.run(debug=True, port=5000)
